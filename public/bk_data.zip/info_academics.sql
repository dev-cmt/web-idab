-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 31, 2023 at 02:43 PM
-- Server version: 10.3.37-MariaDB-cll-lve
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `puneclub_live`
--

-- --------------------------------------------------------

--
-- Table structure for table `info_academics`
--

CREATE TABLE `info_academics` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `collage` varchar(255) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `passing_year` int(11) DEFAULT NULL,
  `degree` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `info_academics`
--

INSERT INTO `info_academics` (`id`, `collage`, `subject`, `passing_year`, `degree`, `created_at`, `updated_at`, `user_id`) VALUES
(1, 'Pune College', 'Computer Science', 1995, 2, '2023-04-05 05:07:55', '2023-04-05 05:07:55', 1),
(2, 'Pune College', 'Computer Science', 1995, 2, '2023-04-05 05:07:56', '2023-04-05 05:07:56', 2),
(3, NULL, NULL, NULL, NULL, '2023-04-05 05:08:06', '2023-04-05 05:08:06', 3),
(4, NULL, NULL, NULL, NULL, '2023-04-05 05:08:07', '2023-04-05 05:08:07', 4),
(5, NULL, NULL, NULL, NULL, '2023-04-05 05:08:07', '2023-04-05 05:08:07', 5),
(6, 'Fergussion College', 'Computer Science', 1997, 2, '2023-04-05 15:38:02', '2023-04-05 15:38:02', 6),
(11, 'Pune College', 'Computer', 1998, 2, '2023-04-06 13:41:01', '2023-04-06 13:41:01', 14),
(12, 'Pune', 'Ghgg', 2022, 4, '2023-04-09 18:38:45', '2023-04-09 18:38:45', 15),
(13, 'Pune College', 'Computer', 1995, 1, '2023-04-15 16:13:29', '2023-04-15 16:13:29', 27),
(14, 'Sinhgad College of Science', 'Financial Management', 2017, 2, '2023-04-15 17:22:44', '2023-04-15 17:22:44', 31),
(15, 'Spicer college', 'BBB', 1999, 2, '2023-04-15 17:23:07', '2023-04-15 17:23:07', 37),
(16, 'Vishwakarma Institute of Information Technology, Kondhwa, Pune.', 'B.Tech Mechanical Engineering', 2018, 2, '2023-04-15 17:25:35', '2023-04-15 17:25:35', 36),
(17, 'Poona college', 'Electronic', 2000, 2, '2023-04-15 17:25:53', '2023-04-15 17:25:53', 33),
(18, 'Ness Wadia College of Commerce', 'Finance', 1999, 2, '2023-04-15 17:26:49', '2023-04-15 17:26:49', 34),
(19, 'Pune college', 'Electronics', 2000, 2, '2023-04-15 17:27:23', '2023-04-15 17:27:23', 35),
(20, 'University of Pune', 'MBA', 1998, 3, '2023-04-15 17:28:27', '2023-04-15 17:28:27', 29),
(21, 'Sinhgad college of science', 'Financial Management', 2017, 3, '2023-04-15 17:34:49', '2023-04-15 17:34:49', 40),
(22, 'Poona College', 'Computer Science', 1999, 2, '2023-04-15 17:40:29', '2023-04-15 17:40:29', 32),
(23, 'Poona College', 'Economics', 2000, 2, '2023-04-15 17:44:54', '2023-04-15 17:44:54', 39),
(24, 'Poona College', 'BCS', 1998, 2, '2023-04-15 17:56:20', '2023-04-15 17:56:20', 30),
(25, 'Pune College', 'Computer Science', 1999, 2, '2023-04-15 19:40:18', '2023-04-15 19:40:18', 43),
(26, 'Ness Wadia College of Commerce', 'Finance', 2017, 2, '2023-04-15 23:46:33', '2023-04-15 23:46:33', 44),
(27, 'Poona College', 'B.Sc. in Computer Science', 2006, 2, '2023-04-16 03:05:05', '2023-04-16 03:05:05', 45),
(28, 'Modern College', 'Economics', 2020, 2, '2023-04-16 05:43:19', '2023-04-16 05:43:19', 46),
(29, 'Department of Management Science (PUMBA)', 'MBA', 2014, 3, '2023-04-16 06:40:14', '2023-04-16 06:40:14', 47),
(30, 'Vishwakarma College of Arts, Commerce, and Science', 'Marketing Management', 2019, 2, '2023-04-16 08:49:47', '2023-04-16 08:49:47', 50),
(31, 'TASMAC', 'MBA', 1998, 3, '2023-04-16 09:59:47', '2023-04-16 09:59:47', 51),
(32, 'Anna Saheb Magar College, Hadapsar, Pune', NULL, NULL, 2, '2023-04-16 10:37:49', '2023-04-16 10:37:49', 52),
(33, 'Fergusson College', 'Computer Science', 1997, 2, '2023-04-16 11:53:49', '2023-04-16 11:53:49', 42),
(34, 'Nowrosjee Wadia College', 'Computer Science', 2004, 2, '2023-04-17 12:14:55', '2023-04-17 12:14:55', 56),
(35, 'Modern College of Engineering', 'Masters in Computer Science & Engineering', 2008, 3, '2023-04-25 18:11:06', '2023-04-25 18:11:06', 58);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `info_academics`
--
ALTER TABLE `info_academics`
  ADD PRIMARY KEY (`id`),
  ADD KEY `info_academics_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `info_academics`
--
ALTER TABLE `info_academics`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 31, 2023 at 02:42 PM
-- Server version: 10.3.37-MariaDB-cll-lve
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `puneclub_live`
--

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `batch` varchar(255) NOT NULL,
  `contact_number` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `two_factor_secret` text DEFAULT NULL,
  `two_factor_recovery_codes` text DEFAULT NULL,
  `two_factor_confirmed_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `current_team_id` bigint(20) UNSIGNED DEFAULT NULL,
  `profile_photo_path` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `is_admin` tinyint(1) NOT NULL DEFAULT 0,
  `cm_adviser` tinyint(1) NOT NULL DEFAULT 0,
  `cm_ecommittee` tinyint(1) NOT NULL DEFAULT 0,
  `cm_welfare` tinyint(1) NOT NULL DEFAULT 0,
  `pune_member` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `batch`, `contact_number`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `two_factor_confirmed_at`, `remember_token`, `current_team_id`, `profile_photo_path`, `status`, `is_admin`, `cm_adviser`, `cm_ecommittee`, `cm_welfare`, `pune_member`, `created_at`, `updated_at`) VALUES
(1, 'Pune Club', '1995', '01720012715', 'admin@gmail.com', '1999-12-31 18:00:00', '$2y$10$ZExizO8uB/dghKNScAoJteYCGLehCoHGBchFOIql6NfZ.McQlRvCS', NULL, NULL, NULL, NULL, NULL, '1681560983_faicon.png', 1, 1, 1, 0, 0, 0, '2023-04-05 05:07:55', '2023-04-15 16:16:50'),
(27, 'Khondoker Arifur Rahman', '1995', '01720012715', 'kh.arifur.rahman@gmail.com', '2023-04-15 22:11:01', '$2y$10$UiL69Cc2grswM9BmIh5edO4pbVwjOP4N0E5fmpwBTZN1KmQz56sxy', NULL, NULL, NULL, NULL, NULL, '1681560809_Khondokar Arifur Rahman.jpg', 1, 1, 1, 1, 1, 1, '2023-04-15 16:10:45', '2023-04-15 20:08:23'),
(28, 'Muhammad Maruf Islam', '2008', '01682472824', 'marufislam00@gmail.com', '2023-04-15 17:40:37', '$2y$10$vFBwjcLaOnxs2c18diQznedZ3.pszLXhZ3/HT/LtKcaYbR/93lvOe', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, '2023-04-15 17:09:46', '2023-04-15 17:40:37'),
(29, 'Riaz Chowdhury', '1993', '01710733466', 'riazchowdhury2013@gmail.com', '2023-04-15 17:17:56', '$2y$10$RXcV9uz/SOHCsRAYcrNh3uu09ouNXVwMqTnU3OPlKaSEHjRZnE5KG', NULL, NULL, NULL, NULL, NULL, '1681565307_IMG_3875.jpeg', 1, 1, 1, 1, 1, 1, '2023-04-15 17:10:02', '2023-04-16 02:40:29'),
(30, 'Anwar Al Amin', '1995', '01819770956', 'aaamin@gmail.com', '2023-04-15 17:15:32', '$2y$10$bDjmLyov36xwiMIRdloWAuwYRZrZNrstcJRTLDIwYDkFvg3Xy5X.y', NULL, NULL, NULL, NULL, NULL, '1681566975_16815664565093142740641029558244.jpg', 1, 1, 0, 0, 0, 1, '2023-04-15 17:10:48', '2023-04-15 18:02:00'),
(31, 'Tamal Ghosh', '2014', '01712414227', 'stgtapu@gmail.com', '2023-04-15 17:18:50', '$2y$10$leTOnRPFm5tFRe3hxofTnuaz1UzPxL8sBR6C2Tq9zUNJ8LcYfX1i2', NULL, NULL, NULL, NULL, NULL, '1681564964_FB_IMG_1681564881583.jpg', 1, 1, 0, 0, 0, 1, '2023-04-15 17:14:22', '2023-04-15 17:31:07'),
(32, 'Md. Zakiul Alam Sarker', '1995', '01711136108', 'tozakiul@gmail.com', '2023-04-15 17:15:34', '$2y$10$5C000RvxTgaMK.lek07w4OTOgDb34.neEwFOw.NlbikMk5NziyBXy', NULL, NULL, NULL, NULL, NULL, '1681566026_16815657374227688527190982562502.jpg', 1, 1, 1, 1, 1, 1, '2023-04-15 17:14:39', '2023-04-15 20:07:31'),
(33, 'SK Ahasanul haque', '1996', '01841200301', 'opu.ahasan@gmail.com', '2023-04-15 17:19:54', '$2y$10$rmW8NNMi0Oy71YZwmT4MveQ1v1ejCzjKD0SRdygaTDiEblh.F3FMa', NULL, NULL, NULL, NULL, NULL, '1681565153_Picsart_22-11-20_12-09-00-994.jpg', 1, 1, 0, 0, 0, 1, '2023-04-15 17:15:39', '2023-04-15 17:31:13'),
(34, 'Mahbub Sobhan Noble', '1996', '01717943953', 'sobhan.mahbub@gmail.com', '2023-04-15 17:20:16', '$2y$10$X6Jjulm5D/R2pXWZgPtOZunxlozuZIum/./EqO7J4YOwxatCGdeK2', NULL, NULL, NULL, NULL, NULL, '1681565209_65630186-B5EC-4CB5-BFA6-78DB64411963.jpeg', 1, 1, 1, 1, 1, 1, '2023-04-15 17:15:52', '2023-04-16 02:41:39'),
(35, 'Hasan Al Mamun', '1994', '01715614806', 'hasan003@gmail.com', '2023-04-15 17:16:50', '$2y$10$GLIp5evanVZGKcK0YwFhdeSaEVQlskf3eiEoIB5khvEu/hR7E4kbu', NULL, NULL, NULL, NULL, NULL, '1681565243_E3F596CB-E74F-4841-A1DC-DB701AE15E46.jpeg', 1, 1, 1, 1, 1, 1, '2023-04-15 17:16:24', '2023-04-16 02:41:08'),
(36, 'Dhruba Jyoti Divya', '2018', '01557269009', 'divya.dhruba@gmail.com', '2023-04-15 17:20:39', '$2y$10$J/lj5i0J1RIW2ZkLR2ZOs.p5n6eGEsPfP9M5InmyLaLwAvcWSjcVO', NULL, NULL, NULL, NULL, NULL, '1681565135_20210702_180853.jpg', 1, 1, 0, 0, 0, 1, '2023-04-15 17:16:28', '2023-04-15 17:31:02'),
(37, 'Md masud karim', '1997', '01618322222', 'masudpune@gmail.com', '2023-04-15 17:19:01', '$2y$10$9zff8GYn8/HWdYm7XTKgc.blw1WYMkpgKRXz0icgOtWkMMibB/03i', NULL, NULL, NULL, NULL, NULL, '1681564987_1C61348F-35D0-4F80-A88A-FE5A668B846F.jpeg', 1, 1, 0, 0, 0, 1, '2023-04-15 17:16:35', '2023-04-15 17:25:08'),
(39, 'Arif Ahmed Rony', '1996', '01613364991', 'rroono@gmail.com', '2023-04-15 17:23:31', '$2y$10$jGViX7NkxrQF44iTBiYQOOKpjkDKIjvUThJcJtOYeluYBK8S1JsdO', NULL, NULL, NULL, NULL, NULL, '1681566294_IMG_20230415_193235.jpg', 1, 1, 0, 0, 0, 1, '2023-04-15 17:19:10', '2023-04-15 17:50:02'),
(40, 'Madhab biswas', '2014', '01763767508', 'Madhobbiswas94@gmail.com', '2023-04-15 17:24:29', '$2y$10$WpUBIDmc4CsXxtPBKEoypuiLNK7u2nsJ2d/244.s1.qkMy5g6Chwm', NULL, NULL, NULL, NULL, NULL, '1681565689_photo.jpg', 1, 1, 0, 0, 0, 1, '2023-04-15 17:24:01', '2023-04-15 17:42:41'),
(41, 'Farrukh Ahmed', '1995', '01713197686', 'fahmed_76@yahoo.com', '2023-04-15 17:38:03', '$2y$10$W1KKrD/yz8ctLIXAWIjh2u.neo1pH2MM8dsaqMuTGRdd9aahKxi9y', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, '2023-04-15 17:37:20', '2023-04-15 17:38:03'),
(42, 'Sk. MD. Reajul Islam Chisty', '1993', '01756937902', 'chistybd2003@gmail.com', '2023-04-15 18:38:56', '$2y$10$EL8UussaGoOmkdiBRDz7aOOe5po7F497urprzJeGDSift15YQWuJG', NULL, NULL, NULL, NULL, NULL, '1681631628_Sk Md.Reajul Islam.jpg', 1, 1, 0, 0, 0, 1, '2023-04-15 18:27:54', '2023-04-16 11:56:07'),
(43, 'Lina Rahman', '1995', '01775533554', 'linarahman76@gmail.com', '2023-04-15 19:41:24', '$2y$10$7zp91KXXLcSRTJ0.1CClSOGjjR5Fwm8gDvKSn2bcMjbWeeaMfwSUK', NULL, NULL, NULL, NULL, NULL, '1681573218_2023-01-22-19-38-33-210.jpg', 1, 1, 0, 0, 0, 1, '2023-04-15 19:25:37', '2023-04-15 20:01:49'),
(44, 'Pronab Roy', '2017', '01681546282', 'pronab.nsu@gmail.com', '2023-04-15 23:37:57', '$2y$10$wKwluA6yUBgmp1/5L8DfKumXXE0ku1R9pW5sfFXinfrYGwgZ/mPC2', NULL, NULL, NULL, NULL, NULL, '1681587989_20230416_014544.jpg', 1, 1, 0, 0, 0, 1, '2023-04-15 23:20:10', '2023-04-16 02:39:00'),
(45, 'Md Golam Rahman Curzon', '2001', '01673616808', 'curzon.se@gmail.com', '2023-04-16 02:57:10', '$2y$10$WeFJTuz2.WVIWuoGdWkzuOcbUc/Zsh7.EQOo8VB.rZakvgGpXIWn.', NULL, NULL, NULL, NULL, NULL, '1681599900_DSC_0110.JPG', 1, 1, 0, 0, 0, 1, '2023-04-16 02:56:44', '2023-04-16 11:55:27'),
(46, 'Abu Saleh Fahim', '2016', '01686005100', 'asfahim121@gmail.com', '2023-04-16 05:40:37', '$2y$10$NgaYWYiCeeA2ss164n6BN.qj8o6bRDkFsAcg9nA88kierwRSKzqUu', NULL, NULL, NULL, NULL, NULL, '1681609394_IMG_20230414_112539.jpg', 1, 1, 0, 0, 0, 1, '2023-04-16 05:40:10', '2023-04-16 11:55:10'),
(47, 'Jewel Kumar Roy', '2009', '01924337923', 'roy.jkkniu@gmail.com', '2023-04-16 06:34:30', '$2y$10$qRblgOMmt2L21YS.PhZFRevcXuTH41N0RssgoXpNdLm/m9SjoNG2u', NULL, NULL, NULL, NULL, NULL, '1681612814_Jewel Kumar Roy - Image 01.jpg', 1, 1, 0, 0, 0, 1, '2023-04-16 06:33:30', '2023-04-16 11:55:22'),
(48, 'ABM FAzlee Rabbi', '2014', '01688674468', 'r.fazlee47@gmail.com', NULL, '$2y$10$plxDwmRZP16p27HA1Eo71OptjbvKUTZXumiD5Q1zcH9fE8qKFQ0hu', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, '2023-04-16 07:44:12', '2023-04-16 07:44:12'),
(49, 'Md.Abu Fuad', '1999', '01916031997', 'fuad_nsk@yahoo.com', NULL, '$2y$10$9Ag4w8Ohy3xSjSmAk.MUueUXk5Ivk6LioPISUkNGDIUBUt5pZhmMS', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, '2023-04-16 08:04:47', '2023-04-16 08:04:47'),
(50, 'Md Rabius Sunny', '2016', '01865160447', 'sunback4198@gmail.com', '2023-04-16 08:45:12', '$2y$10$5CTjfZMQPs76RwImyP..H.LQbTezAU.a.Out5AGYZdOQ2bE55nN72', NULL, NULL, NULL, NULL, NULL, '1681620587_FB_IMG_1681620394703.jpg', 1, 1, 0, 0, 0, 1, '2023-04-16 08:44:49', '2023-04-16 11:55:35'),
(51, 'ASM Zahidul Karim (Emon)', '1995', '8801911461438', 'asmzk0803@gmail.com', NULL, '$2y$10$71vCIEMtTvfzM0ObeJKbNej.QQyQBDPiKESTbrIdtj3r2wOIrpMNK', NULL, NULL, NULL, NULL, NULL, '1681624787_inbound9059126086208785717.jpg', 1, 1, 0, 0, 0, 1, '2023-04-16 09:52:31', '2023-04-16 11:55:16'),
(52, 'Abu Naser Mohammad Mashuk', '1995', '01713363266', 'abu.mashuk@gmail.com', '2023-04-16 10:35:13', '$2y$10$weNQjJQsIlVRIlpQFh45cOF8gusxfkaalQTOogmulOKVZRDpn4Bsa', NULL, NULL, NULL, NULL, NULL, '1681627069_Mashuk-1.jpg', 1, 1, 0, 0, 0, 1, '2023-04-16 10:33:38', '2023-04-16 11:55:04'),
(53, 'Joytu Ghose', '2016', '01785678907', 'joytughose97@gmail.com', '2023-04-16 11:11:24', '$2y$10$ucagj40SFlY.6brL.yn89.Mc7faNnF6rMm2K8lMcp0dT48EKYr1lG', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, '2023-04-16 11:08:21', '2023-04-16 11:11:24'),
(54, 'ABM FAzlee Rabbi', '2014', '01688674468', 'ae.rabbi.1147@gmail.com', NULL, '$2y$10$rTDVzVZpYWeNTjbrdW8wHe.bzN1a3c6McAAulqdyGrFS7KzO6grme', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, '2023-04-16 12:19:11', '2023-04-16 12:19:11'),
(55, 'Md Abu Bakkar Siddique', '1998', '00447894980381', 'dinajpur2002@yahoo.com', NULL, '$2y$10$6AURj.H.qFEPqBku5Bz2EulmRMOOl847M1FihXGDMfaNQQq5tLoJa', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, '2023-04-17 08:23:46', '2023-04-17 08:23:46'),
(56, 'Mohammad Monirul Islam', '2001', '01811481649', 'monirul.shemul@gmail.com', '2023-04-17 12:16:28', '$2y$10$vOXLmUQNAunY9j7ZrfUVtOXvIYXQ.3/tXD2JSO9TwiwRRleN1e6we', NULL, NULL, NULL, NULL, NULL, '1681719295_Monirul Islam Shemul.jpg', 1, 1, 0, 0, 0, 1, '2023-04-17 12:11:29', '2023-04-18 16:56:44'),
(57, 'S. M. SAIFUL HAQUE(LIPON)', '1998', '01972952876', 'mailtosaif@gmail.com', '2023-04-21 01:59:08', '$2y$10$ThY1zUmdTwvVE6THYyXjrO68OdCiZmC4Xc8OjdK0Oeve35gzsRKZm', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, '2023-04-21 01:57:16', '2023-04-21 01:59:08'),
(58, 'Dipak Mondal', '2003', '51951213266', 'askdipak@gmail.com', '2023-04-25 18:04:17', '$2y$10$H2CRjucuyl1rsgI7DGIE7ec4atxRpH.hah9Rqc1NLc7Lv2VFWK0je', NULL, NULL, NULL, NULL, NULL, '1682431866_Dipak Square PP.jpg', 1, 1, 0, 0, 0, 1, '2023-04-25 18:03:42', '2023-04-27 14:02:00'),
(59, 'Md Alamgmail.com', '2002', '0172936117', 'info@gmail.com', NULL, '$2y$10$2WGkAeb2YxqkQOKaJ0TdmuI3BHPN0ZmRv.YEvSgqRtspoJlvQRGPe', NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 0, 0, 0, '2023-07-23 14:21:18', '2023-07-23 14:21:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

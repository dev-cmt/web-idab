-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 31, 2023 at 02:43 PM
-- Server version: 10.3.37-MariaDB-cll-lve
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `puneclub_live`
--

-- --------------------------------------------------------

--
-- Table structure for table `info_others`
--

CREATE TABLE `info_others` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `about_me` text DEFAULT NULL,
  `nick_name` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `designation` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `cover_photo` varchar(255) DEFAULT NULL,
  `favorite` varchar(255) DEFAULT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `youtube_url` varchar(255) DEFAULT NULL,
  `instagram_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `linkedin_url` varchar(255) DEFAULT NULL,
  `whatsapp_url` varchar(255) DEFAULT NULL,
  `telegram_url` varchar(255) DEFAULT NULL,
  `snapchat_url` varchar(255) DEFAULT NULL,
  `tiktok_url` varchar(255) DEFAULT NULL,
  `wechat_url` varchar(255) DEFAULT NULL,
  `discord_url` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `info_others`
--

INSERT INTO `info_others` (`id`, `about_me`, `nick_name`, `phone_number`, `designation`, `company_name`, `cover_photo`, `favorite`, `facebook_url`, `youtube_url`, `instagram_url`, `twitter_url`, `linkedin_url`, `whatsapp_url`, `telegram_url`, `snapchat_url`, `tiktok_url`, `wechat_url`, `discord_url`, `user_id`, `created_at`, `updated_at`) VALUES
(1, NULL, NULL, NULL, 'Managing Director', 'Icon Information Systems Ltd.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2023-04-05 05:07:55', '2023-04-05 05:07:55'),
(2, NULL, NULL, NULL, 'Admin', 'Icon Information Systems Ltd.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 2, '2023-04-05 05:07:56', '2023-04-05 05:07:56'),
(3, NULL, NULL, NULL, 'Deputy General Manager', 'Bangladesh Bank, Head Office', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 3, '2023-04-05 05:08:06', '2023-04-05 05:08:06'),
(4, NULL, NULL, NULL, 'Managing director', 'Icon Information Systems Ltd.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 4, '2023-04-05 05:08:07', '2023-04-05 05:08:07'),
(5, NULL, NULL, NULL, 'Deputy Managing Director', 'Icon Information Systems Ltd.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5, '2023-04-05 05:08:07', '2023-04-05 05:08:07'),
(6, NULL, NULL, NULL, 'DMD', 'Icon Information Systems Ltd', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 6, '2023-04-05 15:38:02', '2023-04-05 15:38:02'),
(11, NULL, NULL, NULL, 'Student', 'Icon ISL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 14, '2023-04-06 13:41:01', '2023-04-06 13:41:01'),
(12, NULL, NULL, NULL, 'Jonior programmer', 'IconIsl', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 15, '2023-04-09 18:38:45', '2023-04-09 18:38:45'),
(13, NULL, NULL, NULL, 'Managing Director', 'Icon ISL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 27, '2023-04-15 16:13:29', '2023-04-15 16:13:29'),
(14, NULL, NULL, NULL, 'Assistant Junior Officer', 'Pubali Bank Limited', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 31, '2023-04-15 17:22:44', '2023-04-15 17:22:44'),
(15, NULL, NULL, NULL, 'Officer', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 37, '2023-04-15 17:23:07', '2023-04-15 17:23:07'),
(16, NULL, NULL, NULL, 'Student', NULL, NULL, NULL, 'https://www.facebook.com/dhruba.divya?mibextid=ZbWKwL', NULL, 'https://instagram.com/dhrubadivya?igshid=ZDdkNTZiNTM=', NULL, 'https://www.linkedin.com/in/divyadhruba', NULL, NULL, NULL, NULL, NULL, NULL, 36, '2023-04-15 17:25:35', '2023-04-19 09:21:45'),
(17, NULL, NULL, NULL, 'Sr manager Data center', 'Standard Chartered Bank', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 33, '2023-04-15 17:25:53', '2023-04-15 17:25:53'),
(18, NULL, NULL, NULL, 'Proprietor', 'NAHAR Marble & Tiles', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 34, '2023-04-15 17:26:49', '2023-04-15 17:26:49'),
(19, NULL, NULL, NULL, 'Proprietor', 'Sattar International', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 35, '2023-04-15 17:27:23', '2023-04-15 17:27:23'),
(20, NULL, NULL, NULL, 'AGM, Supply Chain Management, MGI', 'MGI', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 29, '2023-04-15 17:28:27', '2023-04-15 17:28:27'),
(21, NULL, NULL, NULL, 'Assistant Teacher', 'Primary School', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 40, '2023-04-15 17:34:49', '2023-04-15 17:34:49'),
(22, NULL, NULL, NULL, 'Deputy General Manager(IT)', 'Bangladesh Bank', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 32, '2023-04-15 17:40:29', '2023-04-15 17:40:29'),
(23, NULL, NULL, NULL, 'SPO', 'SIBL', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 39, '2023-04-15 17:44:54', '2023-04-15 17:44:54'),
(24, NULL, NULL, NULL, 'Asst Mgr', 'SCB Bangladesh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 30, '2023-04-15 17:56:20', '2023-04-15 17:56:20'),
(25, NULL, NULL, NULL, 'Head of IT', 'Sunbeams', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 43, '2023-04-15 19:40:18', '2023-04-15 19:40:18'),
(26, NULL, NULL, NULL, 'Senior Executive', 'Abdul Monem Limited', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 44, '2023-04-15 23:46:33', '2023-04-15 23:46:33'),
(27, NULL, NULL, NULL, 'Software Engineer (Principal Officer)', 'Islami Bank Bangladesh Limited', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 45, '2023-04-16 03:05:05', '2023-04-16 03:05:05'),
(28, NULL, NULL, NULL, 'Fellow', 'Teach For Bangladesh', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 46, '2023-04-16 05:43:19', '2023-04-16 05:43:19'),
(29, NULL, NULL, NULL, 'Assistant Professor', 'Jatiya Kabi Kazi Nazrul Islam University', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 47, '2023-04-16 06:40:14', '2023-04-16 06:40:14'),
(30, NULL, NULL, NULL, 'Associate', 'Quantanite', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 50, '2023-04-16 08:49:47', '2023-04-16 08:49:47'),
(31, NULL, NULL, NULL, 'Music Director & Composer', 'Studio Aajob', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 51, '2023-04-16 09:59:47', '2023-04-16 09:59:47'),
(32, NULL, NULL, NULL, 'Manager', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 52, '2023-04-16 10:37:49', '2023-04-16 10:37:49'),
(33, NULL, NULL, NULL, 'Deputy Managing Director', 'Icon Information Systems Ltd.', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 42, '2023-04-16 11:53:49', '2023-04-16 11:53:49'),
(34, NULL, NULL, NULL, 'Assistant Professor', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 56, '2023-04-17 12:14:55', '2023-04-17 12:14:55'),
(35, NULL, NULL, NULL, 'EdTech Coordinator', 'Markham College', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 58, '2023-04-25 18:11:06', '2023-04-25 18:11:06');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `info_others`
--
ALTER TABLE `info_others`
  ADD PRIMARY KEY (`id`),
  ADD KEY `info_others_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `info_others`
--
ALTER TABLE `info_others`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 31, 2023 at 02:43 PM
-- Server version: 10.3.37-MariaDB-cll-lve
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `puneclub_live`
--

-- --------------------------------------------------------

--
-- Table structure for table `lose_members`
--

CREATE TABLE `lose_members` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `batch` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lose_members`
--

INSERT INTO `lose_members` (`id`, `name`, `batch`, `image`, `date`, `description`, `location`, `created_at`, `updated_at`) VALUES
(1, 'Saifu', '1994', '1680763291_Saifu 1995.jpg', NULL, NULL, NULL, '2023-04-06 10:41:31', '2023-04-15 20:10:05'),
(2, 'Ragib Hassan (Linkon)', '1993', '1680763319_Ragib Hassan (Linkon) 1993.jpg', NULL, NULL, NULL, '2023-04-06 10:41:59', '2023-04-06 10:41:59'),
(3, 'Shaddin', '1993', '1680763350_Shaddin_1993.jpg', NULL, NULL, NULL, '2023-04-06 10:42:30', '2023-04-06 10:42:30'),
(4, 'Shimul Khondoker', '1994', '1680763403_Shimul Khondoker 1995.jpg', NULL, NULL, NULL, '2023-04-06 10:43:23', '2023-04-15 20:10:28'),
(5, 'Maruf Hassan', '1997', '1680763446_MarufHassan 1997.jpg', NULL, NULL, NULL, '2023-04-06 10:44:06', '2023-04-06 10:49:11'),
(6, 'Tarinj Du monde (Subit)', '1994', '1680763493_Tarinj Du monde (Subit) 1995.jpg', NULL, NULL, NULL, '2023-04-06 10:44:53', '2023-04-15 20:10:46'),
(7, 'Polash', '1999', '1680763525_Polash .jpg', NULL, NULL, NULL, '2023-04-06 10:45:25', '2023-04-06 10:45:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lose_members`
--
ALTER TABLE `lose_members`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lose_members`
--
ALTER TABLE `lose_members`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 31, 2023 at 02:43 PM
-- Server version: 10.3.37-MariaDB-cll-lve
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `puneclub_live`
--

-- --------------------------------------------------------

--
-- Table structure for table `info_families`
--

CREATE TABLE `info_families` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `child_name` varchar(255) DEFAULT NULL,
  `child_dob` date DEFAULT NULL,
  `child_gender` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `info_families`
--

INSERT INTO `info_families` (`id`, `child_name`, `child_dob`, `child_gender`, `created_at`, `updated_at`, `user_id`) VALUES
(5, 'Mubashira', NULL, 1, '2023-04-15 17:23:07', '2023-04-15 17:23:07', 37),
(6, 'Twasif', '2008-03-24', 0, '2023-04-15 17:25:53', '2023-04-15 17:25:53', 33),
(7, 'Wasif', '2015-02-14', 0, '2023-04-15 17:25:53', '2023-04-15 17:25:53', 33),
(8, 'Maheer Sobhan', '2017-01-07', 0, '2023-04-15 17:26:49', '2023-04-15 17:26:49', 34),
(9, 'Nuwaira Chowdhury Raaida', '2013-06-10', 1, '2023-04-15 17:28:27', '2023-04-15 17:28:27', 29),
(10, 'Md. Abrar Ahbab Sarker', '2007-03-11', 0, '2023-04-15 17:40:29', '2023-04-15 17:40:29', 32),
(11, 'Md Azraf Ahbab Sarker', '2014-03-18', 0, '2023-04-15 17:40:29', '2023-04-15 17:40:29', 32),
(12, 'Nanjiba Rawshan', '2008-12-04', 1, '2023-04-15 17:44:54', '2023-04-15 17:44:54', 39),
(13, 'Abu Musa Ibn Amin', '2010-11-08', 0, '2023-04-15 17:56:20', '2023-04-15 17:56:20', 30),
(14, 'Adnin Tajri', '2003-10-05', 1, '2023-04-15 19:40:18', '2023-04-15 19:40:18', 43),
(15, 'Aysha Rahman Rahaf', '2021-04-22', 1, '2023-04-16 03:05:05', '2023-04-16 03:05:05', 45),
(16, 'Arisha Rahman Reham', '2022-09-12', 1, '2023-04-16 03:05:05', '2023-04-16 03:05:05', 45),
(17, 'Joyanti Roy', '2022-12-14', 1, '2023-04-16 06:40:14', '2023-04-16 06:40:14', 47),
(18, NULL, NULL, 0, '2023-04-16 09:59:47', '2023-04-16 09:59:47', 51),
(19, 'Somoy', '2003-08-15', 0, '2023-04-16 11:53:49', '2023-04-16 11:53:49', 42),
(20, 'Suprova', '2005-12-18', 1, '2023-04-16 11:53:49', '2023-04-16 11:53:49', 42),
(21, NULL, NULL, 0, '2023-04-25 18:11:06', '2023-04-25 18:11:06', 58);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `info_families`
--
ALTER TABLE `info_families`
  ADD PRIMARY KEY (`id`),
  ADD KEY `info_families_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `info_families`
--
ALTER TABLE `info_families`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

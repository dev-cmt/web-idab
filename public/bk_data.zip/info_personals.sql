-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 31, 2023 at 02:43 PM
-- Server version: 10.3.37-MariaDB-cll-lve
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `puneclub_live`
--

-- --------------------------------------------------------

--
-- Table structure for table `info_personals`
--

CREATE TABLE `info_personals` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dob` date DEFAULT NULL,
  `gender` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `marrital_status` int(11) DEFAULT NULL,
  `spouse` varchar(255) DEFAULT NULL,
  `birth_day` date DEFAULT NULL,
  `number_child` int(11) DEFAULT NULL,
  `em_name` int(11) DEFAULT NULL,
  `em_phone` int(11) DEFAULT NULL,
  `em_rleation` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `info_personals`
--

INSERT INTO `info_personals` (`id`, `dob`, `gender`, `address`, `city`, `marrital_status`, `spouse`, `birth_day`, `number_child`, `em_name`, `em_phone`, `em_rleation`, `created_at`, `updated_at`, `user_id`) VALUES
(1, NULL, NULL, 'Shariatpur', 'Dhaka', 0, NULL, NULL, 0, NULL, NULL, NULL, '2023-04-05 05:07:55', '2023-04-05 05:07:55', 1),
(2, NULL, NULL, 'Shariatpur', 'Dhaka', 0, NULL, NULL, 0, NULL, NULL, NULL, '2023-04-05 05:07:55', '2023-04-05 05:07:55', 2),
(3, NULL, NULL, 'Gulshan', 'Dhaka', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-04-05 05:08:06', '2023-04-05 05:08:06', 3),
(4, NULL, NULL, 'Gulshan', 'Dhaka', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-04-05 05:08:07', '2023-04-05 05:08:07', 4),
(5, NULL, NULL, 'Gulshan', 'Dhaka', NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2023-04-05 05:08:07', '2023-04-05 05:08:07', 5),
(6, '1975-02-02', 0, 'Shantibagh', 'Dhaka', 0, NULL, NULL, NULL, NULL, NULL, NULL, '2023-04-05 15:38:02', '2023-04-05 15:38:02', 6),
(12, '2023-04-01', 0, 'Shariatpur', 'Dhaka', 0, NULL, NULL, NULL, NULL, NULL, NULL, '2023-04-06 13:41:01', '2023-04-06 13:41:01', 14),
(13, '2023-04-01', 0, 'Kishoreganj, Dhaka', 'Kishoreganj', 2, NULL, '2023-04-09', NULL, NULL, NULL, NULL, '2023-04-09 18:38:45', '2023-04-09 18:38:45', 15),
(14, '1945-04-26', 0, 'Gazipur', 'Dhaka', 1, NULL, NULL, NULL, NULL, NULL, NULL, '2023-04-15 16:13:29', '2023-04-15 16:13:29', 27),
(15, '1994-04-08', 0, 'Savar, Dhaka', 'Dhaka', 0, NULL, NULL, NULL, NULL, NULL, NULL, '2023-04-15 17:22:44', '2023-04-15 17:22:44', 31),
(16, '1980-11-15', 0, 'Masudpune@gmail.com', 'Dhaka', 1, NULL, NULL, 3, NULL, NULL, NULL, '2023-04-15 17:23:07', '2023-04-15 17:23:07', 37),
(17, '1999-09-17', 0, 'Kayllanpur, Dhaka', 'Dhaka', 0, NULL, NULL, NULL, NULL, NULL, NULL, '2023-04-15 17:25:35', '2023-04-15 17:25:35', 36),
(18, '1977-08-02', 0, 'Block-10/A,Lane-19/16,mirpur,Dhaka', 'Dhaka', 1, 'Sabera akter', '1978-01-01', 2, NULL, NULL, NULL, '2023-04-15 17:25:53', '2023-04-15 17:25:53', 33),
(19, '1975-04-04', 0, 'D-15 Zakir Hossain Road Mohammadpur Dhaka -1207', 'Dhaka', 1, 'Nasrin Sultana', '1982-05-30', 2, NULL, NULL, NULL, '2023-04-15 17:26:49', '2023-04-15 17:26:49', 34),
(20, '1976-02-03', 0, 'Dhanmondi, Dhaka', 'Dhaka', 0, NULL, NULL, NULL, NULL, NULL, NULL, '2023-04-15 17:27:23', '2023-04-15 17:27:23', 35),
(21, '1974-08-28', 0, 'House 3, Road 14, Sector 6, Uttara', 'Dhaka', 1, 'Nusrat Jahan Ishita', '1988-12-20', 1, NULL, NULL, NULL, '2023-04-15 17:28:27', '2023-04-15 17:28:27', 29),
(22, '1994-11-27', 0, 'Mohammadpur', 'Magura', 0, NULL, NULL, NULL, NULL, NULL, NULL, '2023-04-15 17:34:49', '2023-04-15 17:34:49', 40),
(23, '1976-07-06', 0, 'Savar', 'Savar', 1, 'Rahima Khatun', '1979-12-09', 2, NULL, NULL, NULL, '2023-04-15 17:40:29', '2023-04-15 17:40:29', 32),
(24, '1976-11-01', 0, 'Adabor', 'Dhaka', 1, 'Murshida Rahman', '1981-10-10', 1, NULL, NULL, NULL, '2023-04-15 17:44:54', '2023-04-15 17:44:54', 39),
(25, '1974-08-31', 0, 'Mirpur-1', 'Dhaka', 1, 'Refat Sultana', '2010-05-19', 1, NULL, NULL, NULL, '2023-04-15 17:56:20', '2023-04-15 17:56:20', 30),
(26, '1976-07-14', 0, '14-A/3, block D, Salimullah Road, Mohmmadpur,Dhaka', 'Dhaka', 1, 'Khondoker Arifur Rahman', '1975-07-13', 2, NULL, NULL, NULL, '2023-04-15 19:40:18', '2023-04-15 19:40:18', 43),
(27, '1994-10-22', 0, '2, banagram lane, wari. Dhaka-1205. Bangladesh.', 'Dhaka', 1, 'Pritha Parmita Nag', '1996-04-07', 0, NULL, NULL, NULL, '2023-04-15 23:46:33', '2023-04-15 23:46:33', 44),
(28, '1981-09-04', 0, 'Adabor', 'Dhaka', 1, 'Jakia Sultana', '1991-10-09', 2, NULL, NULL, NULL, '2023-04-16 03:05:05', '2023-04-16 03:05:05', 45),
(29, '1997-06-26', 0, 'Ovijan-41/43, Great White House, Flat no-C5, AIM Taha Road, Tongi College Gate, Tongi, Gazipur', 'Dhaka', 0, NULL, NULL, NULL, NULL, NULL, NULL, '2023-04-16 05:43:19', '2023-04-16 05:43:19', 46),
(30, '1991-07-15', 0, 'Department of Finance and Banking, Jatiya Kabi Kazi Nazrul Islam University,  Trishal, Mymensingh, Bangladesh', 'Mymensingh', 1, 'Progga Parmita Nath Tresha', '1996-12-18', 1, NULL, NULL, NULL, '2023-04-16 06:40:14', '2023-04-16 06:40:14', 47),
(31, '1996-03-18', 0, NULL, 'Dhaka', 1, 'Sabrina Kabir Tonima', NULL, NULL, NULL, NULL, NULL, '2023-04-16 08:49:47', '2023-04-16 08:49:47', 50),
(32, '1974-03-08', 0, 'House-17, Flat-B/5, Road-6, Sector -10, Uttara West,  Dhaka-1230', 'Uttara, Dhaka', 1, 'Sadiya Binte Yusuf', NULL, 2, NULL, NULL, NULL, '2023-04-16 09:59:47', '2023-04-16 09:59:47', 51),
(33, '1976-10-10', 0, NULL, 'Chittagong', 0, NULL, NULL, NULL, NULL, NULL, NULL, '2023-04-16 10:37:49', '2023-04-16 10:37:49', 52),
(34, '1975-02-02', 0, 'Santibag', 'Dhaka', 1, 'Pervina Akter', '2023-08-25', 2, NULL, NULL, NULL, '2023-04-16 11:53:49', '2023-04-16 11:53:49', 42),
(35, '1984-01-02', 0, 'Uttara Dhaka', 'Dhaka', 1, NULL, NULL, NULL, NULL, NULL, NULL, '2023-04-17 12:14:55', '2023-04-17 12:14:55', 56),
(36, '1982-11-17', 0, 'Surco, Lima, Peru', 'Lima', 1, 'Shruti Anchan', NULL, 2, NULL, NULL, NULL, '2023-04-25 18:11:06', '2023-04-25 18:11:06', 58);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `info_personals`
--
ALTER TABLE `info_personals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `info_personals_user_id_foreign` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `info_personals`
--
ALTER TABLE `info_personals`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

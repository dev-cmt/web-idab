
<?php $__env->startSection('title', 'Membership Payment'); ?>
<?php $__env->startSection('style'); ?>
    <style>
        .input-hidden {
            position: absolute;
            left: -9999px;
        }
        input[type=radio]:checked + label>img {
            border: 1px solid #fff;
            box-shadow: 0 0 3px 3px #ff0000;
        }
        input[type=radio] + label>img {
            border: 1px dashed #444;
            width: 95px;
            height: 95px;
            transition: 500ms all;
            margin-bottom: 10px;
        }
        input[type=radio]:checked + label>img {
            transform: scale(0.8);
        }
        .box{
            display: none;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
        <div class="container">
            <div class="row g-5">
                <div class="col-lg-6">
                    <div class="card" style="border-radius: 0">
                        <div class="card-header pt-4">
                            <h4 class="card-title">Memeber Details</h4>
                        </div>
                        <div class="card-body">
                            <div class="bootstrap-media">
                                <div class="row d-flex justify-content-center">
                                    <div class="col-lg-12 text-center">
                                        <img class="img-fluid rounded" width="120" src="<?php echo e(asset('public')); ?>/images/profile/<?php echo e(Auth::user()->profile_photo_path); ?>" alt="DexignZone">
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <div class="col-sm-6 col-5">
                                        <h5 class="f-w-500">Name <span class="pull-right">:</span>
                                        </h5>
                                    </div>
                                    <div class="col-sm-6 col-7"><span><?php echo e(Auth::user()->name); ?></span>
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <div class="col-sm-6 col-5">
                                        <h5 class="f-w-500">Email <span class="pull-right">:</span>
                                        </h5>
                                    </div>
                                    <div class="col-sm-6 col-7"><span><?php echo e(Auth::user()->email); ?></span>
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <div class="col-sm-6 col-5">
                                        <h5 class="f-w-500">Member Type <span class="pull-right">:</span>
                                        </h5>
                                    </div>
                                    <div class="col-sm-6 col-7"><span><?php echo e(Auth::user()->memberType->name); ?></span>
                                    </div>
                                </div>
                                <div class="row mt-4">
                                    <div class="col-sm-6 col-5">
                                        <h5 class="f-w-500">Location <span class="pull-right">:</span>
                                        </h5>
                                    </div>
                                    <div class="col-sm-6 col-7"><span><?php echo e(Auth::user()->infoPersonal->parmanent_address); ?></span></div>
                                </div>
                                <div class="row mt-4">
                                    <div class="col-sm-6 col-5">
                                        <h5 class="f-w-500">Joining Date <span class="pull-right">:</span>
                                        </h5>
                                    </div>
                                    <div class="col-sm-6 col-7"><span><?php echo e(date("j F, Y", strtotime(Auth::user()->created_at))); ?></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 form">
                    <?php if(session()->has('success')): ?>
                        <strong class="text-success"><?php echo e(session()->get('success')); ?></strong>
                    <?php endif; ?>
                    <form action="<?php echo e(route('registation-payment.store')); ?>" method="post" enctype="multipart/form-data" class="php-email-form"> 
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="payment_reason_id" value="1">
                        <input type="hidden" name="ref_reason_id">
                        <div class="row g-3">
                            <div class="d-flex justify-content-center" style="border-bottom: 1px dashed #ff0000;">
                                <div>
                                    <input type="radio" name="payment_method_id" id="bKash" class="input-hidden" value="1"/>
                                    <label for="bKash"><img src="<?php echo e(asset('public/images')); ?>/payment/bKash.png" alt="Payment bKash" /></label>
                                
                                    <input type="radio" name="payment_method_id" id="roket" class="input-hidden" value="2"/>
                                    <label for="roket"><img src="<?php echo e(asset('public/images')); ?>/payment/roket.png" alt="Payment roket" /></label>
                                
                                    <input type="radio" name="payment_method_id" id="nagad" class="input-hidden" value="3"/>
                                    <label for="nagad"><img src="<?php echo e(asset('public/images')); ?>/payment/nagad.png" alt="Payment nagad" /></label>
                                    
                                    <input type="radio" name="payment_method_id" id="upay" class="input-hidden" value="4"/>
                                    <label for="upay"><img src="<?php echo e(asset('public/images')); ?>/payment/upay.png" alt="Payment upay"/></label>

                                    <input type="radio" name="payment_method_id" id="card" class="input-hidden" value="5"/>
                                    <label for="card"><img src="<?php echo e(asset('public/images')); ?>/payment/credit-card.png" alt="Payment Card"/></label>

                                    <input type="radio" name="payment_method_id" id="cash" class="input-hidden" value="6"/>
                                    <label for="cashless"><img src="<?php echo e(asset('public/images')); ?>/payment/cashless-payment.png" alt="Payment Cashless"/></label>

                                    <?php $__errorArgs = ['payment_method_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <div class="row mt-2">
                                <div class="col-md-6 mt-2">
                                    <label class="form-label">Payment Number 
                                        <span class="text-danger">*</span>
                                    </label>
                                    <select name="payment_number" id="payment_number" class="form-control form-select  <?php $__errorArgs = ['payment_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" style="height: 40px;">
                                        <option selected disabled>Not Found</option>
                                    </select>
                                    <?php $__errorArgs = ['payment_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mt-2">
                                    <label class="form-label">Transaction Number
                                        <span class="text-danger">*</span>
                                    </label>
                                    <input type="text" name="transaction_number" class="form-control <?php $__errorArgs = ['transaction_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('transaction_number')); ?>" placeholder="XXXXXXXXX">
                                    <?php $__errorArgs = ['transaction_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mt-2">
                                    <label class="form-label">Transfer Number
                                        <span class="text-danger">*</span>
                                    </label>
                                    <input type="text" name="transfer_number" class="form-control <?php $__errorArgs = ['transfer_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="01X-XXXX-XXXX" value="<?php echo e(old('transfer_number')); ?>">
                                    <?php $__errorArgs = ['transfer_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mt-2">
                                    <label class="form-label">Amount</label>
                                    <input type="text" id="amount" class="form-control" value="<?php echo e(auth::user()->memberType->registration_fee); ?>" disabled>
                                    <input type="hidden" name="amount" value="<?php echo e(auth::user()->memberType->registration_fee); ?>">
                                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12 mt-2">
                                    <label class="form-label">Message</label>
                                    <textarea class="form-control py-3" name="message" value="<?php echo e(old('message')); ?>" rows="2" placeholder="Enter your message here..."></textarea>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-10 mt-2">
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </section><!-- End Contact Section -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        //======Get Item Group All Data
        $(document).on('click', 'input[type="radio"]', function() {
            var methodId = $(this).attr("value");
            $.ajax({
                url: '<?php echo e(route('get-payment-number')); ?>', // Make sure the route is correct
                method: 'GET',
                dataType: "json",
                data: {'method_id': methodId},
                success: function(response) {
                    //--Get Customer Type Data
                    var datas = response.data;
                    var payment_number_dr = $('#payment_number');
                    payment_number_dr.empty();
                    payment_number_dr.append('<option disabled selected>--Select--</option>');
                    $.each(datas, function(index, option) {
                        payment_number_dr.append('<option value="' + option.number + '">' + option.number + '</option>');
                    });
                },
                error: function() {
                    alert('Fail');
                }
            });
        });





        // $(document).ready(function(){
        //     $('input[type="radio"]').click(function(){
        //         var inputValue = $(this).attr("value");
        //         var targetBox = $("." + inputValue);
        //         $(".box").not(targetBox).hide();
        //         $(targetBox).show();
        //     });
        // });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web-idab\resources\views/frontend/pages/register_payment.blade.php ENDPATH**/ ?>
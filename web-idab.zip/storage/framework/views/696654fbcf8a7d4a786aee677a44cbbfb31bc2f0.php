    <!--**********************************
                Sidebar start
    ***********************************-->
    <div class="deznav scrollbar">
        <div class="main-profile">
            <div class="image-bx">
                <img src="<?php echo e(asset('public')); ?>/images/profile/<?php echo e(Auth::user()->profile_photo_path); ?>" alt="">
                <a href="javascript:void(0);"><i class="fa fa-cog" aria-hidden="true"></i></a>
            </div>
            <h5 class="name"><?php echo e(Auth::user()->name); ?></h5>
            <p class="email"><a href="mailto:<nowiki> <?php echo e(Auth::user()->email); ?>" class="__cf_email__">[<?php echo e(Auth::user()->email); ?>]</a></p>
        </div>
        <ul class="metismenu" id="menu">
            <li class="nav-label first">Main Menu</li>
            <li><a href="<?php echo e(route('dashboard')); ?>" class="ai-icon" aria-expanded="false">
                    <i class="flaticon-144-layout"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
            </li>

            <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                    <i class="flaticon-381-user-9"></i>
                    <span class="nav-text">Member</span>
                </a>
                <ul aria-expanded="false">
                    <?php $__currentLoopData = $memberType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(Route('member.index', $item->id )); ?>"><?php echo e($item->name); ?> </a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Super-Admin')): ?>
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Member Approve</a>
                        <ul aria-expanded="false">
                            <li><a href="<?php echo e(Route('members-approve.index')); ?>">Member Approve</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Admin')): ?>
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Data Setting</a>
                        <ul aria-expanded="false">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Gallery access','Gallery add','Gallery edit','Gallery delete')): ?>
                                <li><a href="<?php echo e(Route('memebr-type.index')); ?>">Add Member Types</a></li>
                                <li><a href="<?php echo e(Route('memebr-qualification.index')); ?>">Add Qualification</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                <i class="flaticon-003-diamond"></i>
                    <span class="nav-text">My Transactions</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(Route('event_registation_list')); ?>">Annual Fee</a></li>
                    <li><a href="<?php echo e(Route('event_registation_list')); ?>">Event Fee</a></li>
                </ul>
            </li>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Super-Admin')): ?>
            <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                <i class="flaticon-381-database"></i>
                    <span class="nav-text">Payment History</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="#">Annual Fee Details</a></li>
                    <li><a href="#">Event Fee Details</a></li>
                    <li><a href="<?php echo e(Route('transaction-registation.index')); ?>">Registation Fee Details</a></li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Admin')): ?>
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Data Setting</a>
                        <ul aria-expanded="false">
                            
                            <li><a href="<?php echo e(Route('transaction-payment-number.index')); ?>">Setup Payment Number</a></li>
                            
                            <li><a href="#">Setup Annual Fee</a></li>
                            <li><a href="#">Setup Registation Fee</a></li>
                        </ul>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Super-Admin')): ?>
            <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                    <i class="flaticon-077-menu-1"></i>
                    <span class="nav-text">App</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="<?php echo e(Route('profile.show', Auth::user()->id)); ?>">Profile</a></li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Super-Admin')): ?>
                    <li><a href="<?php echo e(route('contact.index')); ?>">Contact Us</a></li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>


            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Super-Admin')): ?>
            <li><a href="<?php echo e(Route('layouts.gallery_image')); ?>" class="ai-icon" aria-expanded="false">
                    <i class="flaticon-063-picture"></i>
                    <span class="nav-text">Gallery</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Super-Admin')): ?>
            <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                    <i class="flaticon-381-settings-2"></i>
                    <span class="nav-text">Setting</span>
                </a>
                <ul aria-expanded="false">

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('User access','User add','User edit','User delete')): ?>
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Approve</a>
                        <ul aria-expanded="false">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Approve Member')): ?>
                                <li><a href="<?php echo e(route('member-approve-index')); ?>">Member Approve</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Approve Member')): ?>
                                <li><a href="<?php echo e(Route('subscription_approve_list')); ?>">Subscription Fees</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Approve Member')): ?>
                                <li><a href="<?php echo e(Route('event_approve_list')); ?>">Event Fees</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Role access','Role add','Role edit','Role delete')): ?>
                        <li><a href="<?php echo e(route('roles.index')); ?>">Role</a></li>
                    <?php endif; ?>

                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('User access','User add','User edit','User delete')): ?>
                    <li><a href="<?php echo e(Route('users.index')); ?>">User</a></li>
                    <?php endif; ?>
                    
                </ul>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Pages access')): ?>
            <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                    <i class="flaticon-049-copy"></i>
                    <span class="nav-text">Pages</span>
                </a>
                <ul aria-expanded="false">
                    <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Gallery</a>
                        <ul aria-expanded="false">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Gallery access','Gallery add','Gallery edit','Gallery delete')): ?>
                                <li><a href="<?php echo e(Route('gallery.index')); ?>">Photo Gallery</a></li>
                            <?php endif; ?>
                            <!--<li><a href="page-error-403.html">Video Gallery</a></li>-->
                        </ul>
                    </li>
                    <li><a href="<?php echo e(route('lose_member.index')); ?>">Lost Member</a></li>
                    <li><a href="<?php echo e(route('event.index')); ?>">Manage Events</a></li>
                </ul>
            </li>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Super-Admin')): ?>
            <li>
                <a href="<?php echo e(route('subscription.index')); ?>" class="ai-icon" aria-expanded="false">
                    <i class="flaticon-147-medal"></i><span class="nav-text">Subscription</span>
                </a>
            </li>
            <?php endif; ?>

        </ul>
        <div class="copyright py-4 my-4">
            
        </div>
    </div>

    <!--**********************************
                Sidebar end
    ***********************************--><?php /**PATH C:\xampp\htdocs\web-idab\resources\views/layouts/partial/sidebar.blade.php ENDPATH**/ ?>
<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <header>
        <h5 style="color: #34ad54;margin-top: 15px;">Member Register</h5>
    </header>
    <!-- Validation Errors -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'jetstream::components.validation-errors','data' => ['style' => 'color:red;margin-bottom:15px;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'color:red;margin-bottom:15px;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
    <form method="POST" action="<?php echo e(route('register')); ?>">
        <?php echo csrf_field(); ?>
        <div class="field">
            <span class="fa fa-user"></span>
            <input id="name" type="text" name="name" placeholder="Your Full Name" :value="old('name')" required autofocus>
        </div>
        <div class="field space">
            <span class="fas fa-code-branch"></span>
            <input id="batch" type="number" name="batch" placeholder="Batch (Year)" :value="old('batch')" required autofocus>
        </div>
        <div class="field space">
            <span class="fas fa-phone"></span>
            <input id="contact_number" type="number" name="contact_number" placeholder="Contact Number" :value="old('contact_number')" required autofocus>
        </div>
        <div class="field space">
            <span class="fas fa-envelope"></span>
            <input type="email" name="email" id="email" placeholder="Email Address" :value="old('email')" required autofocus>
        </div>
        <div class="field space">
            <span class="fa fa-lock"></span>
            <input type="password" name="password" id="password" class="pass-key" placeholder="Password" required autocomplete="new-password">
            <span class="show">SHOW</span>
        </div>
        <div class="field space">
            <span class="fa fa-lock"></span>
            <input type="password" name="password_confirmation" id="password_confirmation" class="pass-key" placeholder="Confirm Password" required autocomplete="new-password">
            <span class="show">SHOW</span>
        </div>
        <div class="field space">
            <input type="submit" value="Register">
        </div>
    </form>
    <div class="signup">Already have account?
        <a href="<?php echo e(route('login')); ?>">Sign in Now</a>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\web-idab\resources\views/auth/register.blade.php ENDPATH**/ ?>
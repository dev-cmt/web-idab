
    <style>
        .resent_verify_btn {
            cursor: pointer;
            color: white;
            background: #ff0000;
            padding: 10px 20px;
            outline: none;
            border: none;
            font-size: 15px;
            font-family: arial;
            width: 100%;
        }
        .resent_verify_btn:hover {
            cursor: pointer;
            color: white;
            background: #a30000;
            transition: 1s;
        }
        .loge_out_btn {
            cursor: pointer;
            color: white;
            background: #272727;
            padding: 10px 20px;
            outline: none;
            border: none;
            font-size: 15px;
            font-family: arial;
            width: 50%;
            margin-top:10px;
            border: 0.5px solid #a3a3a3;
        }
        .loge_out_btn:hover {
            cursor: pointer;
            color: white;
            background: #0f0f0f;
        }
    </style>

<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="content-wrapper py-4" style="background-image: url('<?php echo e(asset('public/images')); ?>/pages/registation-bg.avif'); background-attachment: fixed; overflow:hidden">
        <!-- STAR ANIMATION -->
        <div class="bg-animation">
            <div id='stars'></div>
            <div id='stars2'></div>
            <div id='stars3'></div>
            <div id='stars4'></div>
        </div><!-- / STAR ANIMATION -->
        <div class="login-form">
            <div class="logo">
                <a href="<?php echo e(route('/')); ?>"><img src="<?php echo e(asset('public/images')); ?>/logo.png" alt=""></a>
            </div>
            
            <div class="header">
                <h1 style="font-size: 24px;color: #ff0000;font-weight:500">Your Registation Complete Successfully</h1>
                <?php if(session('status') == 'verification-link-sent'): ?>
                    <p><?php echo e(__('A new verification link has been sent to the email address you provided in your profile settings.')); ?></p>
                <?php endif; ?>
                <div class="bar"></div>
                <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('public/images')); ?>/email.png" style="width:35%" alt=""></a>        
            </div>

            <!-- Message Show -->
            <h5 style="color: #4a00ad;margin: 10px 0px; font-family:arial;font-size:18px">Verification Link Sent to your Email </h5>
            <p style="color:#939393; margin-bottom:20px; padding:0px 15px; font-family:arial;font-size:14px;text-alizen:left">If you didn't receive the email, we will gladly send you another.</p>
        
            <!-- Action Button-->
            <div class="p-4 flex items-center justify-between">
                <div>
                    <form method="POST" action="<?php echo e(route('verification.send')); ?>">
                        <?php echo csrf_field(); ?>
                            <button type="submit" class="resent_verify_btn"><?php echo e(__('Resend Verification Email')); ?></button>
                    </form>
                </div>
                <div>
                    <form method="POST" action="<?php echo e(route('logout')); ?>" class="inline">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="loge_out_btn"><?php echo e(__('Log Out')); ?> </button>
                    </form>
                </div>
            </div>
        </>
    </div>
        
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
    <?php /**PATH C:\xampp\htdocs\web-idab\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>
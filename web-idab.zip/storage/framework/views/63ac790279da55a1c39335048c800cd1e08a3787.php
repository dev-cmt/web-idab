<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = App\View\Components\GuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\GuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="content-wrapper py-4" style="background-image: url('<?php echo e(asset('public/images')); ?>/pages/registation-bg.avif'); background-attachment: fixed;">
        <!-- STAR ANIMATION -->
        <div class="bg-animation">
            <div id='stars'></div>
            <div id='stars2'></div>
            <div id='stars3'></div>
            <div id='stars4'></div>
        </div><!-- / STAR ANIMATION -->
        <div class="login-form">
            <div class="logo">
                <a href="<?php echo e(route('/')); ?>"><img src="<?php echo e(asset('public/images')); ?>/logo.png" alt=""></a>
            </div>
            
            <div class="header">
                <h1>Member Login</h1>
                <div class="bar"></div>
            </div>
        
            <!-- Validation Errors -->
            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'jetstream::components.validation-errors','data' => ['style' => 'color:red; margin-bottom:15px;']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['style' => 'color:red; margin-bottom:15px;']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            <form method="POST" action="<?php echo e(route('login')); ?>" class="px-4 py-2">
                <?php echo csrf_field(); ?>
    
                <div class="input-group">
                    <input type="text" name="email" id="email" class="input-elem" placeholder=" " :value="old('email')" required autofocus/>
                    <label for="email">Email</label>
                </div>
                <div class="input-group">
                    <input type="password" name="password" id="password" class="input-elem" placeholder=" " required  autocomplete="current-password"/>
                    <label for="password">Password</label>
                    <i class="fas fa-eye-slash eye"></i>
                </div>
                <div class="d-flex justify-content-between pb-4">
                    <a href="<?php echo e(route('password.request')); ?>" class="reg_link">Forgot your password?</a>
                </div>
                <button type="submit" class="btn btn-register">Login</button>
                <div class="py-3">Don't have account?
                    
                    <a href="<?php echo e(route('member_register.create')); ?>" class="text-success">Signup in Now</a>
                </div>
            </form>
        </div>
    </div>
        
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
    <?php /**PATH C:\xampp\htdocs\web-idab\resources\views/auth/login.blade.php ENDPATH**/ ?>
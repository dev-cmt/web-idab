
<?php $__env->startSection('title', $membersType); ?>
<?php $__env->startSection('content'); ?>
    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact">
        <div class="container">

            <div class="section-title">
                <h2 class="reveal">If You Have Any Query, Feel Free To Contact Us</h2>
                <p>Et nemo qui impedit suscipit alias ea. Quia fugiat sitin iste officiis commodi quidem hic quas.</p>
            </div>
            <div class="row">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 mb-3">
                    <div class="hover_card_pages wow slideInUp" data-wow-delay="0.3s">
                        <div class="imgBx">
                            <img src="<?php echo e(asset('public/images/profile/'. $row->profile_photo_path)); ?>" alt="images">
                        </div>
                        <div class="hover_card_details">
                            <h2><?php echo e($row->name); ?></h2>
                            <?php if($row->infoCompany->company_name || $row->infoCompany->designation): ?>
                            <h2><span><?php echo e($row->infoCompany->designation); ?></span></h2>
                            <h4><span>(<?php echo e($row->infoCompany->company_name ?? ''); ?>)</span></h4>
                            <?php elseif($row->infoStudent->student_institute || $row->infoStudent->semester): ?>
                            <h2><span><?php echo e($row->infoStudent->student_institute); ?></span></h2>
                            <?php endif; ?>
                        </div>
                        
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

        </div>
    </section><!-- End Contact Section -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\web-idab\resources\views/frontend/pages/member.blade.php ENDPATH**/ ?>